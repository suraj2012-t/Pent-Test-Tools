document.addEventListener('DOMContentLoaded', () => {
  // Theme management
  const body = document.body;
  let isDarkMode = false;

  // Load theme from storage
  browser.storage.local.get('darkMode').then(data => {
    isDarkMode = data.darkMode || false;
    if (isDarkMode) {
      body.classList.add('dark-mode');
    }
  });

  // Toggle theme on settings click
  document.getElementById('settings-btn').addEventListener('click', () => {
    isDarkMode = !isDarkMode;
    body.classList.toggle('dark-mode', isDarkMode);
    browser.storage.local.set({ darkMode: isDarkMode });
  });

  // Tab switching
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(btn => {
    btn.addEventListener('click', () => {
      tabs.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // Operators data
  const operators = [
    { name: 'site:', syntax: 'site:domain', desc: 'Restrict to domain', ex: 'site:example.com' },
    { name: 'inurl:', syntax: 'inurl:keyword', desc: 'URL keywords', ex: 'inurl:admin' },
    { name: 'intitle:', syntax: 'intitle:keyword', desc: 'Title keywords', ex: 'intitle:index.of' },
    { name: 'filetype:', syntax: 'filetype:ext', desc: 'File types', ex: 'filetype:pdf' },
    { name: 'ext:', syntax: 'ext:ext', desc: 'File extensions', ex: 'ext:docx' },
    { name: 'intext:', syntax: 'intext:keyword', desc: 'Body text match', ex: 'intext:password' },
    { name: 'allintext:', syntax: 'allintext:words', desc: 'All words in body', ex: 'allintext:user pass' },
    { name: 'inanchor:', syntax: 'inanchor:keyword', desc: 'Anchor text match', ex: 'inanchor:click here' },
    { name: 'allinanchor:', syntax: 'allinanchor:words', desc: 'All words in anchors', ex: 'allinanchor:buy now' },
    { name: '-', syntax: '-term', desc: 'Exclude/remove', ex: '-site:example.com' },
    { name: '" "', syntax: '"phrase"', desc: 'Exact match', ex: '"admin login"' },
    { name: '*', syntax: 'keyword*', desc: 'Wildcard', ex: 'best * ever' },
    { name: '|', syntax: 'term1 | term2', desc: 'OR', ex: 'cats | dogs' },
    { name: '..', syntax: 'num1..num2', desc: 'Range', ex: '2000..2025' },
    { name: 'related:', syntax: 'related:url', desc: 'Similar sites', ex: 'related:example.com' },
    { name: 'cache:', syntax: 'cache:url', desc: 'Cached version', ex: 'cache:example.com' },
    { name: 'link:', syntax: 'link:url', desc: 'Linking pages', ex: 'link:example.com' }
  ];

  // Populate operators table
  const tableBody = document.getElementById('operators-table');
  operators.forEach(op => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${op.name}</td><td>${op.syntax}</td><td>${op.desc}</td><td>${op.ex}</td>`;
    tableBody.appendChild(row);
  });

  // Operator search
  document.getElementById('operator-search').addEventListener('input', (e) => {
    const filter = e.target.value.toLowerCase();
    tableBody.querySelectorAll('tr').forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(filter) ? '' : 'none';
    });
  });

  // Query building
  const preview = document.getElementById('query-preview');
  let queryParts = [];

  function updatePreview() {
    preview.value = queryParts.join(' ');
    validateQuery();
  }

  function validateQuery() {
    const query = preview.value.trim();
    if (query) {
      document.getElementById('status').textContent = 'Query looks good.';
    } else {
      document.getElementById('status').textContent = '';
    }
  }

  document.getElementById('add-keyword').addEventListener('click', () => {
    const keyword = document.getElementById('keyword-input').value.trim();
    if (keyword) {
      queryParts.push(keyword);
      updatePreview();
      document.getElementById('keyword-input').value = '';
    }
  });

  document.getElementById('add-operator').addEventListener('click', () => {
    let op = document.getElementById('operator-select').value;
    let value = document.getElementById('operator-value').value.trim();
    if (op && value) {
      if (op === '-') {
        queryParts.push(`-${value}`);
      } else if (op === '\"') {
        queryParts.push(`"${value}"`);
      } else {
        queryParts.push(`${op}${value}`);
      }
      updatePreview();
      document.getElementById('operator-value').value = '';
    }
  });

  // Make preview editable and sync changes back
  preview.addEventListener('input', () => {
    queryParts = preview.value.trim().split(/\s+/);
    validateQuery();
  });

  // Search button: Open in new tab, do NOT clear query
  document.getElementById('search-btn').addEventListener('click', () => {
    const query = preview.value.trim();
    if (query) {
      browser.tabs.create({ url: `https://www.google.com/search?q=${encodeURIComponent(query)}` });
      document.getElementById('status').textContent = 'Search executed. Query preserved.';
    } else {
      document.getElementById('status').textContent = 'Build a query first.';
    }
  });

  // Clear button: Only way to remove query
  document.getElementById('clear-btn').addEventListener('click', () => {
    queryParts = [];
    updatePreview();
    document.getElementById('status').textContent = 'Query cleared.';
  });

  // History
  let history = [];
  browser.storage.local.get('dorkHistory').then(data => {
    history = data.dorkHistory || [];
    renderHistory();
  });

  function renderHistory() {
    const list = document.getElementById('history-list');
    list.innerHTML = '';
    history.forEach((q, index) => {
      const li = document.createElement('li');
      li.textContent = q;
      const loadBtn = document.createElement('button');
      loadBtn.textContent = 'Load';
      loadBtn.onclick = () => {
        preview.value = q;
        queryParts = q.split(/\s+/);
        document.querySelector('.tab-btn[data-tab="builder"]').click();
      };
      const delBtn = document.createElement('button');
      delBtn.textContent = 'Delete';

      delBtn.onclick = () => {
        history.splice(index, 1);
        browser.storage.local.set({ dorkHistory: history });
        renderHistory();
      };
      li.append(loadBtn, delBtn);
      list.appendChild(li);
    });
  }

  document.getElementById('save-btn').addEventListener('click', () => {
    const query = preview.value.trim();
    if (query && !history.includes(query)) {
      history.push(query);
      browser.storage.local.set({ dorkHistory: history });
      renderHistory();
      document.getElementById('status').textContent = 'Saved to history.';
    }
  });
});
