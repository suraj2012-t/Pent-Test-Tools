# DorkMaster Pro

A professional Firefox extension for building and executing advanced Google Dork queries with a comprehensive set of operators and an intuitive interface.

## Features

### 🔍 Query Builder
- **Visual Query Construction**: Build complex Google Dork queries using dropdowns and form inputs
- **Live Preview**: Editable query preview that updates in real-time
- **Operator Support**: Comprehensive set of Google search operators including:
  - Site restriction (`site:`)
  - File type filtering (`filetype:`, `ext:`)
  - URL/Title search (`inurl:`, `intitle:`)
  - Text matching (`intext:`, `allintext:`)
  - Exclusion operators (`-`)
  - Exact matching (`"quotes"`)
  - Wildcards (`*`)
  - Logical operators (`|`, `AND`)
  - Date ranges (`..`)
  - And many more

### 📚 Operator Reference
- **Complete Operator Database**: Searchable table with syntax, descriptions, and examples
- **Quick Search**: Filter operators by name or functionality
- **Professional Documentation**: Clear explanations for each operator

### 💾 Query Management
- **History Tracking**: Save and manage your frequently used queries
- **Persistent Queries**: Built queries remain intact after searches
- **One-Click Loading**: Restore saved queries instantly

### 🎨 Professional Interface
- **Modern Design**: Clean, professional UI optimized for security professionals
- **Dark Mode**: Toggle between light and dark themes
- **Responsive Layout**: Optimized for Firefox popup windows
- **Accessibility**: Proper labels and keyboard navigation support

### 📖 Learning Resources
- **Curated References**: Links to authoritative Google Dorking resources
- **Educational Focus**: Emphasis on ethical usage and security research

## Installation

### From Source
1. Download or clone this repository
2. Open Firefox and navigate to `about:debugging`
3. Click "This Firefox" → "Load Temporary Add-on"
4. Select the `manifest.json` file from the extension directory

### Manual Installation
1. Download the latest release
2. Unzip the extension files
3. Load as temporary add-on in Firefox developer mode

## Usage

1. **Building Queries**: Use the Builder tab to construct queries step-by-step
2. **Adding Operators**: Select operators from the dropdown and enter values
3. **Preview Editing**: Directly edit the query in the preview textarea
4. **Searching**: Click the Search button to execute queries in a new Google tab
5. **Saving**: Save useful queries to your history for later use
6. **Theme Toggle**: Click the settings icon (⚙️) to switch between light/dark modes

## Ethical Usage

This tool is designed for:
- ✅ Security research and penetration testing
- ✅ OSINT (Open Source Intelligence) gathering
- ✅ Educational purposes and learning
- ✅ Testing your own websites and applications

**Please use responsibly:**
- Only test systems you own or have explicit permission to test
- Respect website terms of service and robots.txt files
- Follow applicable laws and regulations
- Avoid accessing sensitive or personal information

## Technical Details

- **Manifest Version**: 3 (latest Firefox standard)
- **Permissions**: Storage (for history), Tabs (for search execution)
- **Browser Support**: Firefox 109+
- **Architecture**: Popup-based extension with local storage


## Development

### Prerequisites
- Firefox Developer Edition (recommended)
- Basic knowledge of HTML, CSS, and JavaScript

### Building
No build process required - this is a vanilla JavaScript extension.

## Privacy

- **No Data Collection**: This extension does not collect, store, or transmit any personal data
- **Local Storage Only**: All history and preferences are stored locally on your device
- **No External Requests**: The extension only opens Google search pages in new tabs

## Resources

- [GeeksforGeeks: What is Google Dorking?](https://www.geeksforgeeks.org/ethical-hacking/what-is-google-dorking/)
- [Google Dork Cheatsheet](https://gist.github.com/sundowndev/283efaddbcf896ab405488330d1bbc06)
- [Exploit-DB Google Hacking Database](https://www.exploit-db.com/google-hacking-database)

## Version History

### v1.0.0
- Initial release
- Complete operator support
- Professional UI with dark mode
- Query history management
- Educational resources integration

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

This tool is for educational and authorized security testing purposes only. Users are responsible for ensuring their usage complies with applicable laws and regulations. The developers are not responsible for any misuse of this software.


