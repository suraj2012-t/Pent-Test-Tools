// Clickjacking Detective - Firefox Compatible Popup Script (BULLETPROOF EXPORT)

// Firefox compatibility - use browser API with chrome fallback
const browserAPI = (function() {
    if (typeof browser !== 'undefined') {
        return browser;
    } else if (typeof chrome !== 'undefined') {
        return chrome;
    } else {
        throw new Error('Browser API not available');
    }
})();

class ClickjackingDetective {
    constructor() {
        this.currentUrl = '';
        this.currentTabId = null;
        this.analysisResults = null;
        this.countdownTimer = null;
        this.init();
    }

    init() {
        console.log('Initializing Clickjacking Detective...');
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupPopup());
        } else {
            this.setupPopup();
        }
    }

    setupPopup() {
        console.log('Setting up popup interface...');
        this.bindEvents();
        this.getCurrentTab();
    }

    bindEvents() {
        // Manual test button
        const manualTestBtn = document.getElementById('manualTestBtn');
        if (manualTestBtn) {
            manualTestBtn.addEventListener('click', () => this.performManualTest());
        }

        // Export PoC button
        const exportPocBtn = document.getElementById('exportPocBtn');
        if (exportPocBtn) {
            exportPocBtn.addEventListener('click', () => this.exportPoc());
        }

        // Close iframe button
        const closeIframe = document.getElementById('closeIframe');
        if (closeIframe) {
            closeIframe.addEventListener('click', () => this.closeIframe());
        }
    }

    async getCurrentTab() {
        try {
            console.log('Getting current active tab...');
            const tabs = await browserAPI.tabs.query({active: true, currentWindow: true});

            if (tabs && tabs.length > 0) {
                this.currentUrl = tabs[0].url;
                this.currentTabId = tabs[0].id;

                console.log('Current tab URL:', this.currentUrl);
                console.log('Current tab ID:', this.currentTabId);

                this.displayCurrentUrl(this.currentUrl);
                this.startAnalysis(this.currentTabId);
            } else {
                throw new Error('No active tab found');
            }
        } catch (error) {
            console.error('Error getting current tab:', error);
            this.showError('Unable to access current tab. Please refresh and try again.');
        }
    }

    displayCurrentUrl(url) {
        const urlDisplay = document.getElementById('currentUrl');
        if (urlDisplay) {
            try {
                const urlObj = new URL(url);
                const displayText = urlObj.hostname + urlObj.pathname;
                urlDisplay.textContent = displayText;
                urlDisplay.title = url; // Show full URL on hover
                console.log('Displayed URL:', displayText);
            } catch (e) {
                console.warn('Invalid URL format:', url);
                urlDisplay.textContent = url;
            }
        }
    }

    startAnalysis(tabId) {
        console.log('Starting clickjacking analysis for tab:', tabId);

        // Check if this is a restricted URL
        if (this.isRestrictedUrl(this.currentUrl)) {
            this.showError('Cannot analyze this page. Browser restrictions prevent analysis of system pages.');
            return;
        }

        this.showCountdown();

        // Start 3-second countdown
        let countdown = 3;
        const countdownText = document.getElementById('countdownText');

        this.countdownTimer = setInterval(() => {
            countdown--;
            if (countdownText) {
                countdownText.textContent = countdown.toString();
            }

            if (countdown <= 0) {
                clearInterval(this.countdownTimer);
                this.performAnalysis(tabId);
            }
        }, 1000);
    }

    isRestrictedUrl(url) {
        const restrictedPrefixes = [
            'about:',
            'moz-extension:',
            'chrome:',
            'chrome-extension:',
            'data:',
            'file:',
            'ftp:'
        ];

        return restrictedPrefixes.some(prefix => url.startsWith(prefix));
    }

    showCountdown() {
        this.hideAllSections();
        const countdownContainer = document.getElementById('countdownContainer');
        if (countdownContainer) {
            countdownContainer.style.display = 'flex';
        }
    }

    showLoading() {
        this.hideAllSections();
        const loadingContainer = document.getElementById('loadingContainer');
        if (loadingContainer) {
            loadingContainer.style.display = 'flex';
        }
    }

    hideAllSections() {
        const sections = ['countdownContainer', 'loadingContainer', 'resultsContainer'];
        sections.forEach(sectionId => {
            const section = document.getElementById(sectionId);
            if (section) {
                section.style.display = 'none';
            }
        });
    }

    async performAnalysis(tabId) {
        console.log('Performing header analysis...');
        this.showLoading();

        try {
            // First ensure content script is injected
            await this.ensureContentScriptInjected(tabId);

            // Wait a moment for content script to initialize
            await this.sleep(1000);

            // Send message to content script
            const response = await browserAPI.tabs.sendMessage(tabId, {
                action: 'analyzeHeaders',
                url: this.currentUrl
            });

            if (response && response.success) {
                console.log('Analysis successful:', response.data);
                this.analysisResults = response.data;
                this.displayResults(response.data);
            } else {
                throw new Error(response ? response.error : 'No response from content script');
            }

        } catch (error) {
            console.error('Analysis failed:', error);

            // Try alternative analysis method
            try {
                console.log('Trying alternative analysis method...');
                const fallbackResults = await this.performFallbackAnalysis();
                this.analysisResults = fallbackResults;
                this.displayResults(fallbackResults);
            } catch (fallbackError) {
                console.error('Fallback analysis also failed:', fallbackError);
                this.showError('Unable to analyze this page. This may be due to browser security restrictions or network issues.');
            }
        }
    }

    async ensureContentScriptInjected(tabId) {
        try {
            console.log('Ensuring content script is injected...');

            // Try to inject content script
            await browserAPI.tabs.executeScript(tabId, {
                file: 'content.js',
                runAt: 'document_end'
            });

            console.log('Content script injected successfully');
        } catch (error) {
            console.warn('Content script injection failed:', error.message);
            // This might fail if script is already injected or page is restricted
            // We'll continue anyway as the script might already be there
        }
    }

    async performFallbackAnalysis() {
        console.log('Performing fallback analysis using fetch...');

        try {
            // Try to fetch the current page headers directly from popup
            const response = await fetch(this.currentUrl, {
                method: 'HEAD',
                mode: 'cors',
                cache: 'no-cache'
            });

            const headers = {};
            for (const [key, value] of response.headers.entries()) {
                headers[key.toLowerCase()] = value;
            }

            return this.analyzeHeaders(headers, this.currentUrl);

        } catch (fetchError) {
            console.error('Fetch fallback failed:', fetchError);

            // Final fallback - assume vulnerable if we can't analyze
            return {
                url: this.currentUrl,
                headers: {},
                frameAncestors: null,
                vulnerabilityLevel: 'VULNERABLE',
                timestamp: new Date().toISOString(),
                analysis: {
                    hasXFrameOptions: false,
                    hasCSPFrameAncestors: false,
                    xFrameOptionsValue: null,
                    frameAncestorsValue: null
                },
                note: 'Analysis limited due to browser restrictions. Site may be vulnerable to clickjacking.'
            };
        }
    }

    analyzeHeaders(headers, url) {
        const xFrameOptions = headers['x-frame-options'];
        const csp = headers['content-security-policy'];

        // Parse CSP for frame-ancestors
        let frameAncestors = null;
        if (csp) {
            const frameAncestorsMatch = csp.match(/frame-ancestors\s+([^;]+)/i);
            if (frameAncestorsMatch) {
                frameAncestors = frameAncestorsMatch[1].trim();
            }
        }

        // Determine vulnerability level
        const vulnerabilityLevel = this.assessVulnerability(xFrameOptions, frameAncestors);

        return {
            url: url,
            headers: headers,
            frameAncestors: frameAncestors,
            vulnerabilityLevel: vulnerabilityLevel,
            timestamp: new Date().toISOString(),
            analysis: {
                hasXFrameOptions: !!xFrameOptions,
                hasCSPFrameAncestors: !!frameAncestors,
                xFrameOptionsValue: xFrameOptions || null,
                frameAncestorsValue: frameAncestors || null
            }
        };
    }

    assessVulnerability(xFrameOptions, frameAncestors) {
        // Check for strong protection
        if (xFrameOptions) {
            const xFrameValue = xFrameOptions.toUpperCase();
            if (xFrameValue === 'DENY') {
                return 'PROTECTED';
            } else if (xFrameValue === 'SAMEORIGIN') {
                return 'PARTIAL';
            }
        }

        if (frameAncestors) {
            const ancestors = frameAncestors.toLowerCase();
            if (ancestors.includes("'none'")) {
                return 'PROTECTED';
            } else if (ancestors.includes("'self'")) {
                return 'PARTIAL';
            } else {
                return 'PARTIAL';
            }
        }

        return 'VULNERABLE';
    }

    displayResults(data) {
        console.log('Displaying analysis results:', data);
        this.hideAllSections();

        const resultsContainer = document.getElementById('resultsContainer');
        if (resultsContainer) {
            resultsContainer.style.display = 'block';
        }

        // Update vulnerability status
        this.updateVulnerabilityStatus(data);

        // Update headers analysis
        this.updateHeadersAnalysis(data);

        // Update vulnerability explanation
        this.updateVulnerabilityExplanation(data);

        // Show manual test and export sections
        this.showAdditionalSections();
    }

    updateVulnerabilityStatus(data) {
        const statusSection = document.querySelector('.vulnerability-status');
        const statusIcon = document.getElementById('statusIcon');
        const statusTitle = document.getElementById('statusTitle');
        const statusDescription = document.getElementById('statusDescription');

        if (!statusSection) return;

        // Remove existing status classes
        statusSection.classList.remove('vulnerable', 'protected', 'partial');

        let status, icon, title, description;

        switch (data.vulnerabilityLevel) {
            case 'VULNERABLE':
                status = 'vulnerable';
                icon = '⚠️';
                title = 'Site is Vulnerable';
                description = 'This website is vulnerable to clickjacking attacks';
                break;
            case 'PROTECTED':
                status = 'protected';
                icon = '✅';
                title = 'Site is Protected';
                description = 'This website has proper clickjacking protection';
                break;
            case 'PARTIAL':
                status = 'partial';
                icon = '⚡';
                title = 'Partial Protection';
                description = 'This website has some protection but may still be vulnerable';
                break;
            default:
                status = 'vulnerable';
                icon = '❓';
                title = 'Unknown Status';
                description = 'Unable to determine vulnerability status';
        }

        statusSection.classList.add(status);
        if (statusIcon) statusIcon.textContent = icon;
        if (statusTitle) statusTitle.textContent = title;
        if (statusDescription) statusDescription.textContent = description;
    }

    updateHeadersAnalysis(data) {
        // X-Frame-Options
        const xFrameOptions = document.getElementById('xFrameOptions');
        const xFrameExplanation = document.getElementById('xFrameExplanation');

        if (xFrameOptions && xFrameExplanation) {
            const xFrameValue = data.headers['x-frame-options'] || data.analysis.xFrameOptionsValue;
            if (xFrameValue) {
                xFrameOptions.textContent = xFrameValue;
                xFrameOptions.className = 'header-value present';
                xFrameExplanation.textContent = this.getXFrameOptionsExplanation(xFrameValue);
            } else {
                xFrameOptions.textContent = 'Not Set';
                xFrameOptions.className = 'header-value missing';
                xFrameExplanation.textContent = 'Header not found - site may be vulnerable to clickjacking';
            }
        }

        // Content-Security-Policy
        const cspFrameAncestors = document.getElementById('cspFrameAncestors');
        const cspExplanation = document.getElementById('cspExplanation');

        if (cspFrameAncestors && cspExplanation) {
            const frameAncestors = data.frameAncestors || data.analysis.frameAncestorsValue;
            if (frameAncestors) {
                cspFrameAncestors.textContent = `frame-ancestors ${frameAncestors}`;
                cspFrameAncestors.className = 'header-value present';
                cspExplanation.textContent = this.getFrameAncestorsExplanation(frameAncestors);
            } else {
                cspFrameAncestors.textContent = 'Not Set';
                cspFrameAncestors.className = 'header-value missing';
                cspExplanation.textContent = 'No frame-ancestors directive found in CSP header';
            }
        }
    }

    getXFrameOptionsExplanation(value) {
        const explanations = {
            'DENY': 'Completely prevents the page from being displayed in any frame - provides strong protection',
            'SAMEORIGIN': 'Allows the page to be displayed in frames only on the same origin - provides good protection',
            'ALLOW-FROM': 'Deprecated directive - allows framing from specific origins but not widely supported'
        };
        return explanations[value.toUpperCase()] || 'Custom X-Frame-Options value detected';
    }

    getFrameAncestorsExplanation(value) {
        if (value.includes("'none'")) {
            return "Prevents any domain from framing the content - provides strong protection";
        } else if (value.includes("'self'")) {
            return "Allows framing only from the same origin - provides good protection";
        } else {
            return "Custom frame-ancestors directive detected - review allowed origins";
        }
    }

    updateVulnerabilityExplanation(data) {
        const explanationContent = document.getElementById('explanationContent');
        if (!explanationContent) return;

        let explanation = '';

        if (data.note) {
            explanation = data.note + '\n\n';
        }

        switch (data.vulnerabilityLevel) {
            case 'VULNERABLE':
                explanation += `This website is vulnerable to clickjacking attacks because:

• No X-Frame-Options header is set
• No Content-Security-Policy frame-ancestors directive is configured
• The site can be loaded in an iframe by any external website
• Attackers could overlay this site with malicious content to trick users

Recommendation: Add "X-Frame-Options: DENY" or "Content-Security-Policy: frame-ancestors 'none'" header to prevent framing.`;
                break;

            case 'PROTECTED':
                explanation += `This website is properly protected against clickjacking attacks because:

• Security headers prevent the page from being framed by other websites
• Either X-Frame-Options or CSP frame-ancestors directive is properly configured
• The site cannot be used in malicious iframe attacks

The current configuration provides strong protection against UI redressing attacks.`;
                break;

            case 'PARTIAL':
                explanation += `This website has partial protection against clickjacking attacks:

• Some security headers are configured but may not provide complete protection
• The site may still be vulnerable in certain scenarios
• Consider reviewing and strengthening the current security configuration

Recommendation: Implement stricter frame-ancestors policies or X-Frame-Options settings.`;
                break;

            default:
                explanation += 'Unable to determine the exact vulnerability status. Please check the headers analysis above.';
        }

        explanationContent.textContent = explanation;
    }

    showAdditionalSections() {
        const sections = ['manualTestSection', 'exportSection'];
        sections.forEach(sectionId => {
            const section = document.getElementById(sectionId);
            if (section) {
                section.style.display = 'block';
            }
        });
    }

    performManualTest() {
        console.log('Performing manual clickjacking test');

        const iframeContainer = document.getElementById('iframeContainer');
        const testIframe = document.getElementById('testIframe');

        if (iframeContainer && testIframe) {
            // Show iframe container
            iframeContainer.style.display = 'block';

            // Load current URL in iframe
            testIframe.src = this.currentUrl;
            console.log('Loading URL in iframe:', this.currentUrl);

            // Scroll iframe container into view
            iframeContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    closeIframe() {
        const iframeContainer = document.getElementById('iframeContainer');
        const testIframe = document.getElementById('testIframe');

        if (iframeContainer && testIframe) {
            iframeContainer.style.display = 'none';
            testIframe.src = 'about:blank'; // Clear iframe content
            console.log('Iframe closed');
        }
    }

    // BULLETPROOF EXPORT FUNCTION - GUARANTEED TO WORK
    exportPoc() {
        console.log('Starting bulletproof PoC export...');

        if (!this.currentUrl) {
            alert('No URL available for export');
            return;
        }

        try {
            // Show loading state
            this.showExportLoading();

            // Generate the HTML content
            const pocHtml = this.generatePocHtml();
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const domain = this.getDomainFromUrl(this.currentUrl);
            const filename = `clickjacking-poc-${domain}-${timestamp}.html`;

            console.log('Generated PoC HTML, attempting download...');

            // Use the most reliable download method
            this.performReliableDownload(pocHtml, filename);

        } catch (error) {
            console.error('Export failed:', error);
            this.hideExportLoading();
            alert('Export failed: ' + error.message);
        }
    }

    showExportLoading() {
        const exportBtn = document.getElementById('exportPocBtn');
        if (exportBtn) {
            exportBtn.disabled = true;
            exportBtn.innerHTML = '<span class="btn-icon">⏳</span>Downloading...';
        }
    }

    hideExportLoading() {
        const exportBtn = document.getElementById('exportPocBtn');
        if (exportBtn) {
            exportBtn.disabled = false;
            exportBtn.innerHTML = '<span class="btn-icon">📥</span>Export PoC HTML';
        }
    }

    performReliableDownload(htmlContent, filename) {
        console.log('Attempting reliable download with filename:', filename);

        try {
            // Method 1: Try simple blob download (most reliable)
            const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });

            // Check if we can create a blob URL
            const blobUrl = URL.createObjectURL(blob);
            console.log('Created blob URL:', blobUrl);

            // Create download link
            const downloadLink = document.createElement('a');
            downloadLink.href = blobUrl;
            downloadLink.download = filename;
            downloadLink.style.display = 'none';

            // Add to DOM temporarily
            document.body.appendChild(downloadLink);

            // Trigger download
            console.log('Triggering download...');
            downloadLink.click();

            // Clean up
            document.body.removeChild(downloadLink);

            // Clean up blob URL after a delay
            setTimeout(() => {
                URL.revokeObjectURL(blobUrl);
                console.log('Cleaned up blob URL');
            }, 1000);

            // Show success
            setTimeout(() => {
                this.hideExportLoading();
                this.showDownloadSuccess(filename);
            }, 500);

            console.log('Download initiated successfully');

        } catch (error) {
            console.error('Reliable download failed:', error);

            // Fallback: Try data URL method
            try {
                console.log('Trying data URL fallback...');
                const dataUrl = 'data:text/html;charset=utf-8,' + encodeURIComponent(htmlContent);

                const fallbackLink = document.createElement('a');
                fallbackLink.href = dataUrl;
                fallbackLink.download = filename;
                fallbackLink.style.display = 'none';

                document.body.appendChild(fallbackLink);
                fallbackLink.click();
                document.body.removeChild(fallbackLink);

                setTimeout(() => {
                    this.hideExportLoading();
                    this.showDownloadSuccess(filename);
                }, 500);

                console.log('Data URL download initiated');

            } catch (dataError) {
                console.error('Data URL fallback also failed:', dataError);

                // Final fallback: Show HTML in new window/tab
                try {
                    console.log('Trying new window fallback...');
                    const newWindow = window.open('', '_blank');
                    newWindow.document.write(htmlContent);
                    newWindow.document.close();

                    this.hideExportLoading();
                    alert('PoC opened in new tab. You can save it manually using Ctrl+S or Cmd+S');

                } catch (windowError) {
                    console.error('All download methods failed:', windowError);
                    this.hideExportLoading();

                    // Absolute final fallback: Copy to clipboard
                    if (navigator.clipboard) {
                        navigator.clipboard.writeText(htmlContent).then(() => {
                            alert('PoC HTML copied to clipboard. You can paste it into a text editor and save as .html file');
                        }).catch(() => {
                            alert('Download failed. Please check browser permissions and try again.');
                        });
                    } else {
                        alert('Download failed. Please check browser permissions and try again.');
                    }
                }
            }
        }
    }

    showDownloadSuccess(filename) {
        console.log('Showing download success for:', filename);

        // Create success notification
        const successDiv = document.createElement('div');
        successDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            z-index: 10001;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            max-width: 350px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;
        successDiv.innerHTML = `
            <div style="font-size: 24px; margin-bottom: 10px;">✅</div>
            <div style="font-size: 16px; margin-bottom: 8px;">PoC Export Successful!</div>
            <div style="font-size: 12px; opacity: 0.9;">File: ${filename}</div>
        `;

        document.body.appendChild(successDiv);

        // Remove success message after 4 seconds
        setTimeout(() => {
            if (successDiv.parentNode) {
                successDiv.remove();
            }
        }, 4000);
    }

    generatePocHtml() {
        const domain = this.getDomainFromUrl(this.currentUrl);
        const timestamp = new Date().toISOString();

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clickjacking PoC - ${domain}</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .header h1 {
            margin: 0 0 10px 0;
            font-size: 28px;
            font-weight: 700;
        }

        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }

        .info {
            padding: 25px;
            background: #fef2f2;
            border-left: 4px solid #dc2626;
            margin: 25px;
            border-radius: 8px;
        }

        .info h3 {
            margin: 0 0 15px 0;
            color: #991b1b;
            font-size: 18px;
        }

        .info p {
            margin: 8px 0;
            line-height: 1.6;
        }

        .info strong {
            color: #991b1b;
        }

        .iframe-container {
            margin: 25px;
            border: 3px solid #dc2626;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .iframe-header {
            background: #fee2e2;
            padding: 15px 20px;
            font-weight: 700;
            color: #991b1b;
            font-size: 14px;
        }

        iframe {
            width: 100%;
            height: 600px;
            border: none;
            display: block;
        }

        .footer {
            padding: 20px;
            background: #f9fafb;
            font-size: 12px;
            color: #6b7280;
            text-align: center;
            border-top: 1px solid #e5e7eb;
        }

        .warning-badge {
            background: #dc2626;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚨 Clickjacking Vulnerability Demonstration</h1>
            <p>Proof of Concept Report for ${domain}</p>
        </div>

        <div class="info">
            <div class="warning-badge">SECURITY VULNERABILITY</div>
            <h3>⚠️ Clickjacking Attack Demonstration</h3>
            <p><strong>Target URL:</strong> ${this.currentUrl}</p>
            <p><strong>Vulnerability Type:</strong> UI Redressing / Clickjacking</p>
            <p><strong>Risk Level:</strong> Medium to High</p>
            <p><strong>Description:</strong> The website below can be embedded in an iframe, making it vulnerable to clickjacking attacks where malicious sites can overlay invisible elements to trick users into unintended actions.</p>
            <p><strong>Impact:</strong> Attackers could potentially trick users into clicking buttons, submitting forms, or performing actions they didn't intend to perform.</p>
            <p><strong>Generated:</strong> ${timestamp}</p>
        </div>

        <div class="iframe-container">
            <div class="iframe-header">
                🔍 TARGET WEBSITE LOADED IN IFRAME (Clickjacking Demonstration):
            </div>
            <iframe src="${this.currentUrl}" title="Clickjacking vulnerability demonstration" sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-navigation"></iframe>
        </div>

        <div class="footer">
            <strong>Generated by Clickjacking Detective Firefox Extension</strong><br>
            This report demonstrates a potential security vulnerability. 
            Recommendation: Add X-Frame-Options: DENY or Content-Security-Policy: frame-ancestors 'none' header to prevent framing.
        </div>
    </div>
</body>
</html>`;
    }

    getDomainFromUrl(url) {
        try {
            const hostname = new URL(url).hostname;
            return hostname.replace(/[^a-zA-Z0-9.-]/g, '').toLowerCase();
        } catch (e) {
            return 'unknown-domain';
        }
    }

    showError(message) {
        console.error('Showing error:', message);
        this.hideAllSections();

        // Create error display
        const statusSection = document.getElementById('statusSection');
        if (statusSection) {
            statusSection.innerHTML = `
                <div class="error-container" style="text-align: center; padding: 40px 20px;">
                    <div class="error-icon" style="font-size: 48px; margin-bottom: 20px;">❌</div>
                    <div class="error-content">
                        <h3 style="color: #dc2626; margin-bottom: 10px;">Analysis Error</h3>
                        <p style="color: #6b7280; line-height: 1.5;">${message}</p>
                    </div>
                </div>
            `;
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize when DOM is ready
console.log('Clickjacking Detective popup script loaded');
new ClickjackingDetective();
