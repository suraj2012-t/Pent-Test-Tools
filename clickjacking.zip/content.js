// Clickjacking Detective - Firefox Content Script (Fixed Notification Button)

// Firefox compatibility - use browser API with chrome fallback
const browserAPI = (function() {
    if (typeof browser !== 'undefined') {
        return browser;
    } else if (typeof chrome !== 'undefined') {
        return chrome;
    } else {
        console.warn('No browser API available');
        return null;
    }
})();

console.log('Clickjacking Detective: Content script initializing...');

class ClickjackingAnalyzer {
    constructor() {
        this.headers = {};
        this.analysisComplete = false;
        this.currentUrl = window.location.href;
        this.notificationShown = false;
        this.init();
    }

    init() {
        console.log('Clickjacking Detective: Content script loaded for', this.currentUrl);

        // Set up message listener immediately
        if (browserAPI && browserAPI.runtime && browserAPI.runtime.onMessage) {
            browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
                return this.handleMessage(message, sender, sendResponse);
            });
        } else {
            console.warn('Browser runtime API not available');
        }

        // Wait for page to be fully loaded then auto-analyze
        this.waitForPageLoad();
    }

    waitForPageLoad() {
        if (document.readyState === 'complete') {
            console.log('Page already complete, starting auto-analysis in 3 seconds...');
            setTimeout(() => this.performAutoAnalysis(), 3000);
        } else if (document.readyState === 'interactive') {
            console.log('Page interactive, waiting for load event...');
            window.addEventListener('load', () => {
                setTimeout(() => this.performAutoAnalysis(), 3000);
            });
        } else {
            console.log('Page still loading, waiting for DOMContentLoaded...');
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => this.waitForCompleteLoad(), 1000);
            });
        }
    }

    waitForCompleteLoad() {
        if (document.readyState === 'complete') {
            setTimeout(() => this.performAutoAnalysis(), 3000);
        } else {
            window.addEventListener('load', () => {
                setTimeout(() => this.performAutoAnalysis(), 3000);
            });
        }
    }

    async performAutoAnalysis() {
        try {
            console.log('Clickjacking Detective: Starting auto-analysis for', this.currentUrl);
            await this.analyzePageHeaders();
            this.analysisComplete = true;

            // Show automatic vulnerability notification
            const analysisData = this.generateAnalysisResults();
            this.showPageNotification(analysisData);

            console.log('Clickjacking Detective: Auto-analysis complete');
        } catch (error) {
            console.error('Clickjacking Detective: Auto-analysis failed:', error);
            this.analysisComplete = true;
        }
    }

    showPageNotification(data) {
        // Don't show notification for certain pages
        if (this.shouldSkipNotification()) {
            return;
        }

        if (this.notificationShown) {
            return; // Already shown
        }

        this.notificationShown = true;

        let title, message, type;

        switch (data.vulnerabilityLevel) {
            case 'VULNERABLE':
                title = '⚠️ Clickjacking Vulnerability Detected!';
                message = 'This website can be loaded in an iframe and may be vulnerable to clickjacking attacks.';
                type = 'danger';
                break;
            case 'PROTECTED':
                title = '✅ Site Protected';
                message = 'This website has proper clickjacking protection headers.';
                type = 'success';
                break;
            case 'PARTIAL':
                title = '⚡ Partial Protection';
                message = 'This website has some clickjacking protection but may still be vulnerable.';
                type = 'warning';
                break;
            default:
                return; // Don't show notification for unknown status
        }

        this.createPageNotification(title, message, type);
    }

    shouldSkipNotification() {
        // Skip notifications for certain types of pages
        const skipPatterns = [
            /^about:/,
            /^moz-extension:/,
            /^chrome:/,
            /^chrome-extension:/,
            /^data:/,
            /^file:/,
            /localhost/,
            /127\.0\.0\.1/,
            /192\.168\./,
            /10\./,
            /172\.(1[6-9]|2\d|3[01])\./
        ];

        return skipPatterns.some(pattern => pattern.test(this.currentUrl));
    }

    createPageNotification(title, message, type) {
        // Remove any existing notifications
        const existingNotifications = document.querySelectorAll('.clickjacking-notification');
        existingNotifications.forEach(notification => notification.remove());

        // Create notification element
        const notification = document.createElement('div');
        notification.className = `clickjacking-notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
                <div class="notification-actions">
                    <button class="notification-btn details">Check Extension for Details</button>
                    <button class="notification-btn close">&times;</button>
                </div>
            </div>
        `;

        // Add styles for notification
        const style = document.createElement('style');
        style.id = 'clickjacking-notification-styles';
        style.textContent = `
            .clickjacking-notification {
                position: fixed !important;
                top: 20px !important;
                right: 20px !important;
                max-width: 320px !important;
                padding: 16px !important;
                border-radius: 8px !important;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
                z-index: 2147483647 !important;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                font-size: 14px !important;
                animation: slideInRight 0.4s ease-out !important;
                backdrop-filter: blur(10px) !important;
            }
            .clickjacking-notification.danger {
                background: rgba(254, 226, 226, 0.95) !important;
                border: 1px solid #fecaca !important;
                color: #991b1b !important;
            }
            .clickjacking-notification.success {
                background: rgba(220, 252, 231, 0.95) !important;
                border: 1px solid #bbf7d0 !important;
                color: #166534 !important;
            }
            .clickjacking-notification.warning {
                background: rgba(254, 243, 199, 0.95) !important;
                border: 1px solid #fde68a !important;
                color: #92400e !important;
            }
            .clickjacking-notification .notification-content {
                display: flex !important;
                flex-direction: column !important;
                gap: 8px !important;
            }
            .clickjacking-notification .notification-title {
                font-weight: 700 !important;
                font-size: 14px !important;
                margin: 0 !important;
            }
            .clickjacking-notification .notification-message {
                font-size: 12px !important;
                line-height: 1.4 !important;
                opacity: 0.9 !important;
                margin: 0 !important;
            }
            .clickjacking-notification .notification-actions {
                display: flex !important;
                gap: 8px !important;
                margin-top: 8px !important;
            }
            .clickjacking-notification .notification-btn {
                padding: 6px 12px !important;
                border: none !important;
                border-radius: 4px !important;
                font-size: 11px !important;
                font-weight: 600 !important;
                cursor: pointer !important;
                transition: all 0.2s ease !important;
                background: rgba(255,255,255,0.8) !important;
                color: inherit !important;
                flex: 1 !important;
            }
            .clickjacking-notification .notification-btn:hover {
                background: rgba(255,255,255,1) !important;
                transform: translateY(-1px) !important;
            }
            .clickjacking-notification .notification-btn.close {
                background: rgba(0,0,0,0.1) !important;
                color: inherit !important;
                padding: 4px 8px !important;
                font-size: 14px !important;
                flex: 0 0 auto !important;
            }
            .clickjacking-notification .notification-btn.details {
                background: rgba(255,255,255,0.9) !important;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%) !important; opacity: 0 !important; }
                to { transform: translateX(0) !important; opacity: 1 !important; }
            }
            @keyframes slideOutRight {
                from { transform: translateX(0) !important; opacity: 1 !important; }
                to { transform: translateX(100%) !important; opacity: 0 !important; }
            }
        `;

        // Add to page
        if (!document.getElementById('clickjacking-notification-styles')) {
            document.head.appendChild(style);
        }
        document.body.appendChild(notification);

        // Auto close after 8 seconds
        const autoCloseTimer = setTimeout(() => {
            this.removeNotification(notification);
        }, 8000);

        // Manual close button
        const closeBtn = notification.querySelector('.notification-btn.close');
        closeBtn.addEventListener('click', () => {
            clearTimeout(autoCloseTimer);
            this.removeNotification(notification);
        });

        // Details button - show helpful message
        const detailsBtn = notification.querySelector('.notification-btn.details');
        detailsBtn.addEventListener('click', () => {
            clearTimeout(autoCloseTimer);
            this.removeNotification(notification);
            this.showDetailsMessage();
        });
    }

    showDetailsMessage() {
        // Create a simple info message
        const infoMsg = document.createElement('div');
        infoMsg.className = 'clickjacking-info-message';
        infoMsg.innerHTML = `
            <div class="info-content">
                <div class="info-icon">🛡️</div>
                <div class="info-text">
                    <strong>Click the Clickjacking Detective extension icon in your browser toolbar for detailed analysis</strong>
                </div>
            </div>
        `;

        // Add styles for info message
        const style = document.createElement('style');
        style.textContent = `
            .clickjacking-info-message {
                position: fixed !important;
                top: 80px !important;
                right: 20px !important;
                max-width: 300px !important;
                background: rgba(59, 130, 246, 0.95) !important;
                color: white !important;
                padding: 16px !important;
                border-radius: 8px !important;
                box-shadow: 0 8px 25px rgba(0,0,0,0.2) !important;
                z-index: 2147483646 !important;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                font-size: 13px !important;
                animation: slideInRight 0.4s ease-out !important;
            }
            .clickjacking-info-message .info-content {
                display: flex !important;
                align-items: center !important;
                gap: 12px !important;
            }
            .clickjacking-info-message .info-icon {
                font-size: 24px !important;
            }
            .clickjacking-info-message .info-text {
                line-height: 1.4 !important;
            }
        `;

        document.head.appendChild(style);
        document.body.appendChild(infoMsg);

        // Auto remove after 4 seconds
        setTimeout(() => {
            if (infoMsg.parentNode) {
                infoMsg.remove();
                style.remove();
            }
        }, 4000);
    }

    removeNotification(notification) {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }

    async handleMessage(message, sender, sendResponse) {
        console.log('Clickjacking Detective: Received message:', message);

        if (message.action === 'analyzeHeaders') {
            try {
                // If analysis hasn't completed yet, do it now
                if (!this.analysisComplete) {
                    console.log('Analysis not complete, running now...');
                    await this.analyzePageHeaders();
                }

                const analysisData = this.generateAnalysisResults();
                console.log('Sending analysis results:', analysisData);

                sendResponse({
                    success: true,
                    data: analysisData
                });
            } catch (error) {
                console.error('Clickjacking Detective: Analysis error:', error);

                // Send fallback response
                const fallbackData = this.generateFallbackResults(error);
                sendResponse({
                    success: true,
                    data: fallbackData
                });
            }
            return true; // Keep message channel open for async response
        }

        return false;
    }

    async analyzePageHeaders() {
        const currentUrl = window.location.href;
        console.log('Analyzing headers for:', currentUrl);

        // Reset headers
        this.headers = {};

        try {
            // Method 1: Try HEAD request
            console.log('Trying HEAD request...');
            const headResponse = await fetch(currentUrl, {
                method: 'HEAD',
                cache: 'no-cache',
                credentials: 'same-origin',
                mode: 'cors'
            });

            if (headResponse.ok) {
                this.extractHeaders(headResponse);
                console.log('HEAD request successful');
                return;
            } else {
                console.log('HEAD request failed with status:', headResponse.status);
            }

        } catch (headError) {
            console.log('HEAD request failed:', headError.message);
        }

        try {
            // Method 2: Try GET request
            console.log('Trying GET request...');
            const getResponse = await fetch(currentUrl, {
                cache: 'no-cache',
                credentials: 'same-origin',
                mode: 'cors'
            });

            if (getResponse.ok) {
                this.extractHeaders(getResponse);
                console.log('GET request successful');
                return;
            } else {
                console.log('GET request failed with status:', getResponse.status);
            }

        } catch (getError) {
            console.log('GET request failed:', getError.message);
        }

        try {
            // Method 3: Try same-origin request
            console.log('Trying same-origin request...');
            const sameOriginResponse = await fetch(currentUrl, {
                cache: 'no-cache',
                credentials: 'same-origin',
                mode: 'same-origin'
            });

            if (sameOriginResponse.ok) {
                this.extractHeaders(sameOriginResponse);
                console.log('Same-origin request successful');
                return;
            }

        } catch (sameOriginError) {
            console.log('Same-origin request failed:', sameOriginError.message);
        }

        // Method 4: Analyze document for meta tags and other indicators
        console.log('All fetch methods failed, analyzing document...');
        this.analyzeDocumentSecurity();
    }

    extractHeaders(response) {
        console.log('Extracting headers from response');

        // Clear previous headers
        this.headers = {};

        // Extract headers
        for (let [key, value] of response.headers.entries()) {
            this.headers[key.toLowerCase()] = value;
            console.log(`Header: ${key} = ${value}`);
        }

        // Log important security headers
        const securityHeaders = [
            'x-frame-options',
            'content-security-policy',
            'x-content-type-options',
            'x-xss-protection',
            'strict-transport-security'
        ];

        console.log('Security headers found:');
        securityHeaders.forEach(header => {
            if (this.headers[header]) {
                console.log(`✓ ${header}: ${this.headers[header]}`);
            } else {
                console.log(`✗ ${header}: Not set`);
            }
        });
    }

    analyzeDocumentSecurity() {
        console.log('Analyzing document for security indicators');

        // Check meta tags for security headers
        const metaTags = document.querySelectorAll('meta[http-equiv]');
        metaTags.forEach(meta => {
            const httpEquiv = meta.getAttribute('http-equiv');
            const content = meta.getAttribute('content');

            if (httpEquiv && content) {
                const headerName = httpEquiv.toLowerCase();
                this.headers[headerName] = content;
                console.log(`Found meta header: ${headerName} = ${content}`);
            }
        });

        // Check for frame-busting scripts (informational only)
        const frameBustingDetected = this.detectFrameBusting();
        if (frameBustingDetected) {
            console.log('Frame-busting JavaScript detected (informational)');
        }

        // If still no headers found, this likely means the site is vulnerable
        const hasAnyProtection = this.headers['x-frame-options'] || 
                                 this.headers['content-security-policy'];

        if (!hasAnyProtection) {
            console.log('No clickjacking protection headers found - site likely vulnerable');
        }
    }

    detectFrameBusting() {
        try {
            // Look for common frame-busting patterns
            const scripts = document.querySelectorAll('script');
            let frameBustingDetected = false;

            scripts.forEach(script => {
                const scriptContent = script.textContent || script.innerText || '';

                // Common frame-busting patterns
                const frameBustingPatterns = [
                    /if\s*\(\s*top\s*[!=]=?\s*self\s*\)/,
                    /if\s*\(\s*self\s*[!=]=?\s*top\s*\)/,
                    /top\.location\s*=\s*self\.location/,
                    /top\.location\.href\s*=\s*self\.location\.href/,
                    /parent\.location\s*=\s*self\.location/,
                    /window\.top\s*[!=]==?\s*window\.self/
                ];

                frameBustingPatterns.forEach(pattern => {
                    if (pattern.test(scriptContent)) {
                        frameBustingDetected = true;
                    }
                });
            });

            return frameBustingDetected;
        } catch (error) {
            console.log('Error detecting frame busting:', error);
            return false;
        }
    }

    generateAnalysisResults() {
        const xFrameOptions = this.headers['x-frame-options'];
        const csp = this.headers['content-security-policy'];

        // Parse CSP for frame-ancestors
        let frameAncestors = null;
        if (csp) {
            const frameAncestorsMatch = csp.match(/frame-ancestors\s+([^;]+)/i);
            if (frameAncestorsMatch) {
                frameAncestors = frameAncestorsMatch[1].trim();
            }
        }

        // Determine vulnerability level
        const vulnerabilityLevel = this.assessVulnerability(xFrameOptions, frameAncestors);

        const results = {
            url: this.currentUrl,
            headers: this.headers,
            frameAncestors: frameAncestors,
            vulnerabilityLevel: vulnerabilityLevel,
            timestamp: new Date().toISOString(),
            analysis: {
                hasXFrameOptions: !!xFrameOptions,
                hasCSPFrameAncestors: !!frameAncestors,
                xFrameOptionsValue: xFrameOptions || null,
                frameAncestorsValue: frameAncestors || null
            }
        };

        console.log('Generated analysis results:', results);
        return results;
    }

    generateFallbackResults(error) {
        console.log('Generating fallback results due to error:', error);

        return {
            url: this.currentUrl,
            headers: {},
            frameAncestors: null,
            vulnerabilityLevel: 'VULNERABLE',
            timestamp: new Date().toISOString(),
            analysis: {
                hasXFrameOptions: false,
                hasCSPFrameAncestors: false,
                xFrameOptionsValue: null,
                frameAncestorsValue: null
            },
            note: 'Could not analyze security headers due to browser restrictions. This usually indicates the site may be vulnerable to clickjacking attacks. Try the manual test to confirm.',
            error: error.message
        };
    }

    assessVulnerability(xFrameOptions, frameAncestors) {
        // Check for strong protection
        if (xFrameOptions) {
            const xFrameValue = xFrameOptions.toUpperCase();
            if (xFrameValue === 'DENY') {
                return 'PROTECTED';
            } else if (xFrameValue === 'SAMEORIGIN') {
                return 'PARTIAL';
            } else if (xFrameValue.startsWith('ALLOW-FROM')) {
                return 'PARTIAL';
            }
        }

        if (frameAncestors) {
            const ancestors = frameAncestors.toLowerCase();
            if (ancestors.includes("'none'")) {
                return 'PROTECTED';
            } else if (ancestors.includes("'self'")) {
                return 'PARTIAL';
            } else {
                // Has custom frame-ancestors but not none/self
                return 'PARTIAL';
            }
        }

        // No clickjacking protection found
        return 'VULNERABLE';
    }
}

// Initialize the analyzer
try {
    console.log('Clickjacking Detective: Initializing content script analyzer');
    const analyzer = new ClickjackingAnalyzer();

    // Make analyzer available globally for debugging
    window.clickjackingAnalyzer = analyzer;

    console.log('Clickjacking Detective: Content script initialization complete');
} catch (error) {
    console.error('Clickjacking Detective: Failed to initialize content script:', error);
}
